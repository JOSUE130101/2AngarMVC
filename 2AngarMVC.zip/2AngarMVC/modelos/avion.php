<?php
class Avion
{
    private $pdo;              // Objeto de conexión a la base de datos
    private $avion_id;         // ID único del avión
    private $avion_nombre;     // Nombre/modelo del avión
    private $avion_marca;      // Fabricante del avión
    private $avion_placa;      // Matrícula/placa del avión
    private $avion_aerolinea;  // Aerolínea a la que pertenece
    private $cantidad;         // Cantidad disponible (si aplica)

    // Constructor para establecer la conexión a la base de datos
    public function __CONSTRUCT()
    {
        $this->pdo = BasedeDatos::Conectar();
    }

    // ========== GETTERS Y SETTERS ========== //

    public function getAvionId(): ?int
    {
        return $this->avion_id;
    }

    public function setAvionId(int $id)
    {
        $this->avion_id = $id;
    }

    public function getAvionNombre(): ?string
    {
        return $this->avion_nombre;
    }

    public function setAvionNombre(string $nombre)
    {
        $this->avion_nombre = $nombre;
    }

    public function getAvionMarca(): ?string
    {
        return $this->avion_marca;
    }

    public function setAvionMarca(string $marca)
    {
        $this->avion_marca = $marca;
    }

    public function getAvionPlaca(): ?string
    {
        return $this->avion_placa;
    }

    public function setAvionPlaca(string $placa)
    {
        $this->avion_placa = $placa;
    }

    public function getAvionAerolinea(): ?string
    {
        return $this->avion_aerolinea;
    }

    public function setAvionAerolinea(string $aerolinea)
    {
        $this->avion_aerolinea = $aerolinea;
    }

    public function getCantidad(): ?int
    {
        return $this->cantidad;
    }

    public function setCantidad(int $cantidad)
    {
        $this->cantidad = $cantidad;
    }

    // ========== MÉTODOS CRUD ========== //

    /**
     * Obtiene el total de aviones registrados
     */
    public function Cantidad() {
        try {
            $consulta = $this->pdo->prepare("SELECT COUNT(*) as total_aviones FROM aviones");
            $consulta->execute();
            $resultado = $consulta->fetch(PDO::FETCH_OBJ);
            return $resultado ? $resultado : (object)['total_aviones' => 0];
        } catch(Exception $e) {
            // Registra el error pero devuelve un objeto válido
            error_log("Error contando aviones: " . $e->getMessage());
            return (object)['total_aviones' => 0];
        }
    }
    public function Listar() {
        try {
            $consulta = $this->pdo->prepare("SELECT * FROM aviones");
            $consulta->execute();
            return $consulta->fetchAll(PDO::FETCH_OBJ);
        } catch(Exception $e) {
            die("Error al listar aviones: " . $e->getMessage());
        }
    }

    public function Obtener($id) {
        try {
            $consulta = $this->pdo->prepare("SELECT * FROM aviones
        WHERE avion_id=?;"  );
            $consulta->execute(array($id));
            $r=$consulta->fetch(PDO::FETCH_OBJ);
            $p=new avion();
            $p->setAvionId($r->avion_id);
            $p->setAvionNombre($r->avion_nombre);
            $p->setAvionMarca($r->avion_marca);
            $p->setAvionPlaca($r->avion_placa);
            $p->setAvionAerolinea($r->avion_aerolinea);
            $p->setCantidad($r->cantidad);

          return $p;





        } catch(Exception $e) {
            die("Error al listar aviones: " . $e->getMessage());
        }
    }



    public function Insertar(avion $p) {
        try {
            $consulta = 'INSERT INTO aviones (avion_nombre, avion_marca, avion_placa, avion_aerolinea, cantidad) VALUES (?, ?, ?, ?, ?)';
            $this->pdo->prepare($consulta)
                ->execute(array(
                    $p->getAvionNombre(),
                    $p->getAvionMarca(),
                    $p->getAvionPlaca(),
                    $p->getAvionAerolinea(),
                    $p->getCantidad()
                ));
        } catch(Exception $e) {
            die($e->getMessage());
        }
    }

    public function Actualizar(avion $p) {
        try {
            $consulta = "UPDATE aviones set
            avion_nombre=?,
            avion_marca=?,
            avion_placa=?,
            avion_aerolinea=?,
            cantidad=?
            where avion_id=?;
            
            ";
            $this->pdo->prepare($consulta)
                ->execute(array(
                    $p->getAvionNombre(),
                    $p->getAvionMarca(),
                    $p->getAvionPlaca(),
                    $p->getAvionAerolinea(),
                    $p->getCantidad(),
                    $p->getAvionId()
                ));
        } catch(Exception $e) {
            die($e->getMessage());
        }
    }


    public function Eliminar ($id) {
        try {
            $consulta = "DELETE FROM aviones where avion_id=?; ";
            $this->pdo->prepare($consulta)
                ->execute(array($id ));
        } catch(Exception $e) {
            die($e->getMessage());
        }
    }







}
?>