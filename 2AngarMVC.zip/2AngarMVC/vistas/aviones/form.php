<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i> Aviones</h1>
            <p>Ingresa los datos para registrar un avion</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>aviones</li>
              <li><a href="#"><?=$titulo?> avion</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-6">
                  <div class="well bs-component">
                    <form class="form-horizontal" method="POST"action="?c=avion&a=Guardar">
                      <fieldset>
                        <legend><?=$titulo?> avion</legend>
                        <div class="form-group">
                          
                   
                            <input class="form-control" name="avion_id" type="hidden" value="<?=$p->getAvionId()?>">


                            <label class="col-lg-2 control-label" for="Nombre">nombre</label>
                          <div class="col-lg-10">
                            <input required class="form-control" name="Nombre" type="texto" placeholder="nombre avion" value="<?=$p->getAvionNombre()?>">
                            
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="marca">marca</label>
                          <div class="col-lg-10">
                            <input required class="form-control" name="marca" type="texto" placeholder="marca"value="<?=$p->getAvionMarca()?>">
                           
                          </div>
                        </div>


                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="placa">placa</label>
                          <div class="col-lg-10">
                            <input  required class="form-control" name="placa" type="texto" placeholder="placa"value="<?=$p->getAvionPlaca()?>">
                           
                          </div>
                        </div>
 
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="aerolinea">aeroliena</label>
                          <div class="col-lg-10">
                            <input required class="form-control" name="aerolinea" type="texto" placeholder="aerolinea"value="<?=$p->getAvionAerolinea()?>">
                           
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="cantidad"></label>
                          <div class="col-lg-10">
                            <input  required class="form-control" name="cantidad" type="number" placeholder="cantidad"value="<?=$p->getCantidad()?>">
                           
                          </div>
                        </div>












                        
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-default" type="reset">Cancelar</button>
                            <button class="btn btn-primary" type="submit">Enviar</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
             
            </div>
          </div>
        </div>
      </div>
    </div>