<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Data Table</h1>
            <ul class="breadcrumb side">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Tables</li>
              <li class="active"><a href="#">Data Table</a></li>
            </ul>
          </div>
          <div><a class="btn btn-primary btn-flat" href="?c=avion&a=FormCrear"><i class="fa fa-lg fa-plus"></i></a>

          </div>

          
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>avion_id</th>
                      <th>avion_nombre</th>
                      <th>avion_marca</th>
                      <th>avion_placa</th>
                      <th>avion_aerolineea</th>
                      <th>cantidad</th>
                      <th>Accioness</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php foreach($this->modelo->listar() as $r): ?>
    <tr>
        <td><?=$r->avion_id?></td>
        <td><?=$r->avion_nombre?></td>
        <td><?=$r->avion_marca?></td>
        <td><?=$r->avion_placa?></td>
        <td><?=$r->avion_aerolinea?></td>
        <td><?=$r->cantidad?></td>


        <td>
            <a class="btn btn-info btn-flat" href="?c=avion&a=FormCrear&id=<?=$r->avion_id?>"><i class="fa fa-lg fa-refresh"></i></a> 
        
        
        
            <a class="btn btn-warning btn-flat" href="?c=avion&a=Borrar&id=<?=$r->avion_id?>"><i class="fa fa-lg fa-trash"></i></a></div>
    
          </td>
          </tr>

             <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>