 
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
            <p>A free and modular admin template</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li><a href="#">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="card">
            <h3 class="card-title">Cantidad de aviones</h3>
<p>
    <?php 
    $resultado = $this->modelo->Cantidad();
    echo $resultado->total_aviones ?? '0';
    ?>
</p>
<h3>Listado de Aviones</h3>

<?php $aviones = $this->modelo->Listar(); ?>

<?php if (!empty($aviones)): ?>
    <ul>
        <?php foreach($aviones as $avion): ?>
            <li>
                <strong><?= htmlspecialchars($avion->avion_nombre ?? 'Avión') ?></strong>
                (Placa: <?= htmlspecialchars($avion->avion_placa ?? 'N/A') ?>)
                <?= isset($avion->aerolinea) ? ' - ' . htmlspecialchars($avion->aerolinea) : '' ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No hay aviones registrados</p>
<?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>