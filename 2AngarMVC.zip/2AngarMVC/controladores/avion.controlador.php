<?php
require_once "modelos/avion.php";

class AvionControlador {
    private $modelo;
    
    public function __CONSTRUCT() {
        $this->modelo = new Avion();
    }
    
    public function Inicio() {
        $aviones = $this->modelo->listar();
        require_once "vistas/encabezado.php";
        require_once "vistas/aviones/index.php";
        require_once "vistas/pie.php";
    }

    public function FormCrear(){

            $titulo="Registrar";
            $p=new avion();
            if(isset($_GET['id'])) {
               $p= $this->modelo->Obtener($_GET['id']);
               $titulo="modificar";
            }
        

        require_once "vistas/encabezado.php";
        require_once "vistas/aviones/form.php";
        require_once "vistas/pie.php";
    }

    public function Guardar() {
        $p = new avion();
        $p->setAvionId(intval($_POST['avion_id']));
        $p->setAvionNombre($_POST['Nombre']);
        $p->setAvionMarca($_POST['marca']);
        $p->setAvionPlaca($_POST['placa']);
        $p->setAvionAerolinea($_POST['aerolinea']);
        $p->setCantidad($_POST['cantidad']);
        

        $p->getAvionId()> 0 ?
        $this->modelo->Actualizar($p) :
        $this->modelo->Insertar($p);

        header("location:?c=avion");
    }

    public function Borrar(){
        $this->modelo->Eliminar($_GET["id"]);
        header("location:?c=avion");
    }





}
